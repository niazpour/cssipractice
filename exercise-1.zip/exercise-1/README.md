# Day 3: Code Along - Jquery

Copy to your local computer and open up the files! 

You will see an `.html` file and a `.css` file with some code in it. You should also see an empty `.js` file. This is where you will be adding your code throughout the lesson.  Open the `posters.html` file in your browser and remember to refresh it whenever you save some new code to `script.js`

### JQuery:

This `poster.html` file is linked to the JS library JQuery which we will be using to manipulate the `.html` and `.css` code in the browser.

## Resources:

* [JQuery Documentation](https://api.jquery.com/)
* [JQuery on W3Schools](http://www.w3schools.com/jquery/jquery_ref_selectors.asp3)

